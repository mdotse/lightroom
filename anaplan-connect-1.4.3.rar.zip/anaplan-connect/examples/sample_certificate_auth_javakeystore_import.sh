#!/bin/sh
# For MAC OS : This example explains the usage of Certificate Authentication with Java KeyStore with Anaplan Connect.
# It also loads a source text file and runs an Anaplan import into a module.
# For details of how to configure this script visit https://help.anaplan.com/anapedia/Content/Downloads/DL_Downloads.html


KeyStorePath="Your JKS Path"
KeyStorePass="Your JKS Password"
KeyStoreAlias="Your JKS Alias"
WorkspaceId="My Workspace"
ModelId="My Model"
ServiceUrl="https://api.anaplan.com"
AuthUrl="https://auth.anaplan.com"
ImportName="My Import Action"
FileName="File Name In Import Data Source"
FilePath="File Path on the Client"
ChunkSize=1
ErrorDump="My Import Error Dump Location on the client"

Operation="-debug -service ${ServiceUrl} -auth ${AuthUrl} -workspace ${WorkspaceId} -model ${ModelId} -chunksize ${ChunkSize} -file '${FileName}' -put ${FilePath} -import '${ImportName}' -execute -output '${ErrorDump}' "

#____________________________ Do not edit below this line ______________________________

if [ "${KeyStorePath}" ]; then
 Credentials="-keystore ${KeyStorePath} -keystorepass ${KeyStorePass} -keystorealias ${KeyStoreAlias}"    
fi

echo cd "`dirname "$0"`"
cd "`dirname "$0"`"
if [ ! -f AnaplanClient.sh ]; then
  echo "Please ensure this script is in the same directory as AnaplanClient.sh." >&2
  exit 1
elif [ ! -x AnaplanClient.sh ]; then
  echo "Please ensure you have executable permissions on AnaplanClient.sh." >&2
  exit 1
fi
Command="./AnaplanClient.sh ${Credentials} ${Operation} "
/bin/echo "${Command}"
exec /bin/sh -c "${Command}"